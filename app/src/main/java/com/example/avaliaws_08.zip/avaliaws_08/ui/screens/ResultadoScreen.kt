package com.example.avaliaws_08.ui.screens
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavController

@Composable
fun ResultadoScreen(navController: NavController){
    Text("Resultado")
}
