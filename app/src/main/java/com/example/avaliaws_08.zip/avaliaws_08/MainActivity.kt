package com.example.avaliaws_08

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.avaliaws_08.model.Competidor
import com.example.avaliaws_08.model.Entrega
import com.example.avaliaws_08.service.Testador
import com.example.avaliaws_08.ui.theme.AvaliaWS08Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Testador().testarDominio()
        enableEdgeToEdge()

        setContent {
            AvaliaWS08Theme {
                Text("Teste executado")
            }
        }
    }
}